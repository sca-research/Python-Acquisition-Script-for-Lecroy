- Unzip "scale.zip"

- export SCALE_ROOT="/home/scale/Documents/New_Scale/scale"

- install dependencies
  sudo apt-get install gcc-arm-none-eabi lpc21isp

-  sudo ln scale_*.sh /usr/local/bin/
-  cd ${SCALE_ROOT}/PROJECT_NAME
-  scale_clean.sh
-  scale_build.sh "PROJECT_NAME"
-  sudo scale_upload.sh "PROJECT_NAME"


- press and hold the GPI   switch,  
  press and hold the reset switch,
  release        the reset switch,
  release        the GPI   switch.
