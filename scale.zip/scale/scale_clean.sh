#!/bin/bash

rm *.map *.hex *.elf *.bin
