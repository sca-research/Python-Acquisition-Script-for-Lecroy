/* Copyright (C) 2017 Daniel Page <dan@phoo.org>
 *
 * Use of this source code is restricted per the CC BY-SA license, a copy of
 * which can be found via http://creativecommons.org (and should be included 
 * as LICENSE.txt within the associated archive or repository).
 */

#include "example.h"

char x[] = "hello world\n";

int main( int argc, char* argv[] ) {
  target_init();

  while( true ) {
    bool t = target_gpio_rd( GPIO_PIN_GPI        );
             target_gpio_wr( GPIO_PIN_GPO, t     );

             target_gpio_wr( GPIO_PIN_TRG, true  );

    target_wait_ms( 500 );

             target_gpio_wr( GPIO_PIN_TRG, false );

    target_wait_ms( 500 );

    int n = strlen( x );

    for( int i = 0; i < n; i++ ) {
      target_uart_wr( x[ i ] );
    }
  }

  return 0;
}
