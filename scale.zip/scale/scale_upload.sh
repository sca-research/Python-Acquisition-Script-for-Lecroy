#!/bin/bash

sudo lpc21isp ${1}.hex /dev/ttyUSB0 115200 14746
