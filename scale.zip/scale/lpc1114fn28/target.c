/* Copyright (C) 2017 Daniel Page <dan@phoo.org>
 *
 * Use of this source code is restricted per the CC BY-SA license, a copy of
 * which can be found via http://creativecommons.org (and should be included 
 * as LICENSE.txt within the associated archive or repository).
 */

/* Throughout the following, note that all Chapter, Section, Page references 
 * are to the lpc1114fn28 user manual at
 *
 * http://www.nxp.com/docs/en/user-guide/UM10398.pdf
 */

#include "target.h"

syscon_dev_t* SYSCON = ( syscon_dev_t* )( 0x40048000 ); // Figure 6: memory mapping
 iocon_dev_t*  IOCON = (  iocon_dev_t* )( 0x40044000 ); // Figure 6: memory mapping
  gpio_dev_t*  GPIO0 = (   gpio_dev_t* )( 0x50000000 ); // Figure 6: memory mapping
  uart_dev_t*   UART = (   uart_dev_t* )( 0x40008000 ); // Figure 6: memory mapping
   i2c_dev_t*    I2C = (    i2c_dev_t* )( 0x40000000 ); // Figure 6: memory mapping

void target_init() {
  /* Chapter 3 details various general system configuration registers(s).  A
   * central part of the system configuration is control of clock generation
   * and routing: we need to enable the clock for each peripheral on the AHB
   * bus that's of interest, for example.
   */

  SYSCON->SYSAHBCLKCTRL |=  ( 0x1 <<  5 ) ; // Table  21: enable I2C   clock
  SYSCON->PRESETCTRL    &= ~( 0x1 <<  6 ) ; // Table   9: reset  I2C
  SYSCON->PRESETCTRL    |=  ( 0x1 <<  6 ) ;

  SYSCON->SYSAHBCLKCTRL |=  ( 0x1 <<  6 ) ; // Table  21: enable GPIO  clock
  SYSCON->SYSAHBCLKCTRL |=  ( 0x1 << 12 ) ; // Table  21: enable UART  clock
  SYSCON->SYSAHBCLKCTRL |=  ( 0x1 << 16 ) ; // Table  21: enable IOCON clock

  /* The majority of I/O pins have a configurable role; the configuration is
   * outlined in Chapter 8, which is used to match all target-specific pins.
   */

  IOCON->PIO0_4          =  ( 0x1 <<  0 ) | // Table 116: configure PIO0_4 as I2C (SCL)
                            ( 0x2 <<  8 ) ; // Table 116: configure PIO0_4 in fast mode plus (@ 1MHz)
  IOCON->PIO0_5          =  ( 0x1 <<  0 ) | // Table 117: configure PIO0_5 as I2C (SDA)
                            ( 0x2 <<  8 ) ; // Table 117: configure PIO0_5 in fast mode plus (@ 1MHz)

  IOCON->PIO0_8          =  ( 0x0 <<  0 ) ; // Table 128: configure PIO0_8 as GPIO
  IOCON->PIO0_9          =  ( 0x0 <<  0 ) ; // Table 129: configure PIO0_9 as GPIO
  IOCON->PIO0_1          =  ( 0x0 <<  0 ) | // Table 109: configure PIO0_1 as GPIO
                            ( 0x2 <<  3 ) ; // Table 109: configure PIO0_1 in pull-up mode

  IOCON->PIO1_6          =  ( 0x1 <<  0 ) ; // Table 145: configure PIO1_6 as UART RxD
  IOCON->PIO1_7          =  ( 0x1 <<  0 ) ; // Table 146: configure PIO1_7 as UART TxD

  /* Chapter 12 details the (GP)I/O ports.
   *
   * For each target-specific pin, we need to set the direction and also an
   * initial value.
   */

  GPIO0->GPIOnDIR       |=  ( 0x1 <<  8 ) ; // Table 175: PIO0_8 = output => GPIO_PIN_TRG
  GPIO0->GPIOnDIR       |=  ( 0x1 <<  9 ) ; // Table 175: PIO0_9 = output => GPIO_PIN_GPO
  GPIO0->GPIOnDIR       &= ~( 0x1 <<  1 ) ; // Table 175: PIO0_1 = input  => GPIO_PIN_GPI

  GPIO0->GPIOnDATA      &= ~( 0x1 <<  8 ) ; // initialise GPIO_PIN_TRG = 0
  GPIO0->GPIOnDATA      &= ~( 0x1 <<  9 ) ; // initialise GPIO_PIN_GPO = 0

  /* Chapter 13 details the UART.
   * 
   * We need to 
   * 
   * 1. configure the baud rate,
   * 2. configure the frame format, then
   * 3. enable the USART.
   *
   * Section 13.5.15 expands upon the first task, stating that
   *
   * UART baud rate = PCLK / ( 16 * ( 256 * U0DLM + U0DLL ) * ( 1 + ( DivAddVal / MulVal ) ) ) ,
   * 
   * so, per Table 201, for a 12 MHz core clock freq. we set 
   *
   * DivAddVal =  0 
   *    MulVal =  1
   *     U0DLM =  0
   *     U0DLL = 78
   */
 
  SYSCON->UARTCLKDIV     =  1;

  UART->U0LCR           |=  ( 0x1 <<  7 ) ; // Table 193:  enable divisor latch access
  UART->U0FDR            =  ( 0x0 <<  0 ) ; // Table 200: set DivAddVal
  UART->U0FDR           |=  ( 0x1 <<  4 ) ; // Table 200: set    MulVal
  UART->U0DLM            =  0;              // Table 187: set divisor latch MSBs
  UART->U0DLL            = 78;              // Table 187: set divisor latch LSBs
  UART->U0LCR           &= ~( 0x1 <<  7 ) ; // Table 193: disable divisor latch access 

  UART->U0LCR           |=  ( 0x3 <<  0 ) ; // Table 193: 8 data bits
  UART->U0LCR           &= ~( 0x1 <<  3 ) ; // Table 193: no parity
  UART->U0LCR           &= ~( 0x1 <<  2 ) ; // Table 193: 1 stop bits

  /* Chapter 15 details the I2C interface.
   *
   * We need to configure the clock generator so it matches the required I2C
   * clock frequency of 1 MHz (fast mode plus).  Section 26.5.2 says
   *
   * SCL freq. = core clock freq. / ( SCLH + SCLL ) ,
   *
   * st. SCLH, SCLL > 4; per Table 226, for a 12 MHz core clock freq. we set
   * SCLH = SCLL = 6 (meaning SCLH + SCLL = 12).
   */

  SYSCON->PRESETCTRL    |=  ( 0x1 <<  1 ) ; // Table   9: disable I2C bus reset

  I2C->SCLL              =  6;              // Table 225: set -ve, low  duty cycle
  I2C->SCLH              =  6;              // Table 224: set +ve, high duty cycle

  I2C->CONSET            =  ( 0x1 <<  6 ) ; // Table 220: enable  I2C bus

  return;
}

void target_wait_us( int x ) {
  /* At 12 MHz, there are 12 cycles per us; the Cortex-M0 documentation at
   * 
   * http://infocenter.arm.com/help/topic/com.arm.doc.ddi0432c/CHDCICDF.html
   * 
   * states (in Table 3.1) that
   * 
   * sub -> 1 cycle
   * bne -> 1 cycle if not taken, or 3 cycles otherwise
   *
   * so for 4 cycles per loop (bar the last), we need 3 loops per us.
   */

  if( x > 0 ) {
    __asm__ __volatile__( "0: sub %0, #1 ; bne 0b ;" : : "r" (3*x) : "cc" );
  }

  return;
}

void target_wait_ms( int x ) {
  for( int i = 0; i < x; i++ ) {
    target_wait_us( 1000 );
  }
}

uint8_t target_uart_rd(           ) {
  while( !( UART->U0LSR & ( 0x1 << 0 ) ) );
  return ( UART->U0RBR     );
}

void    target_uart_wr( uint8_t x ) {
  while( !( UART->U0LSR & ( 0x1 << 5 ) ) );
         ( UART->U0THR = x );
  return;
}

bool target_gpio_rd( gpio_pin_t p         ) {
  switch( p ) {
    case GPIO_PIN_TRG : {
      return ( GPIO0->GPIOnDATA >> 8 ) & 0x1;
    }
    case GPIO_PIN_GPO : {
      return ( GPIO0->GPIOnDATA >> 9 ) & 0x1;
    }
    case GPIO_PIN_GPI : {
      return ( GPIO0->GPIOnDATA >> 1 ) & 0x1;
    }
  }

  return false;
}

void target_gpio_wr( gpio_pin_t p, bool x ) {
  switch( p ) {
    case GPIO_PIN_TRG : {
      if( x ) {
        GPIO0->GPIOnDATA |=  ( 0x1 << 8 );
      }
      else {
        GPIO0->GPIOnDATA &= ~( 0x1 << 8 );
      }
      break;
    }
    case GPIO_PIN_GPO : {
      if( x ) {
        GPIO0->GPIOnDATA |=  ( 0x1 << 9 );
      }
      else {
        GPIO0->GPIOnDATA &= ~( 0x1 << 9 );
      }
      break;
    }
    case GPIO_PIN_GPI : {
      if( x ) {
        GPIO0->GPIOnDATA |=  ( 0x1 << 1 );
      }
      else {
        GPIO0->GPIOnDATA &= ~( 0x1 << 1 );
      }
      break;
    }
  }

  return;
}

i2c_status_t target_i2c_fsm( i2c_addr_t a, i2c_mode_t m, uint8_t* x, size_t n ) {
          I2C->CONSET = ( 1 << 5 ) ;    // set   STA

  while( true ) {
    switch( I2C->STAT & 0xF8 ) {
      case 0xF8 : { // Table 242, shared   : no information
          break;
      }
      case 0x00 : { // Table 242, shared   : bus error
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_FAILURE;
      }
      case 0x08 : { // Section 15.11.3, shared   :        start => addr
          I2C->DAT    = ( a << 1 ) | m; // set   addr
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) ;    // clear STO

          break;
      }
      case 0x10 : { // Section 15.11.3, shared   : repeat start => addr
          I2C->DAT    = ( a << 1 ) | m; // set   addr
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) ;    // clear STO

          break;
      }
      case 0x18 : { // Section 15.11.3, transmit : addr         =>  ACK
        if( n > 0 ) {
          I2C->DAT    = *x++;           // set   data
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA

          break;
        }
        else {
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI 
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_SUCCESS;
        }
      }
      case 0x20 : { // Section 15.11.3, transmit : addr         => NACK
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_FAILURE_NACK_ADDR;
      }
      case 0x28 : { // Section 15.11.3, transmit : data         =>  ACK
        if( --n == 0 ) {
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI 
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_SUCCESS;
        }
        else {
          I2C->DAT    = *x++;           // set   data
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI 
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA          

          break;
        }
      }
      case 0x30 : { // Section 15.11.3, transmit : data         => NACK
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_FAILURE_NACK_DATA;
      }
      case 0x38 : { // Section 15.11.3, transmit : arbitration error
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 5 ) ;    // set   STA
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) ;    // clear STO

          break;
      }
      case 0x40 : { // Section 15.11.3, receive  : addr         =>  ACK
        if( n > 1 ) {
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA

          break;
        }
        else {
          I2C->CONCLR = ( 1 << 2 ) |    // clear AA 
                        ( 1 << 3 ) |    // clear SI
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA

          break;
        }
      }
      case 0x48 : { // Section 15.11.3, receive  : addr         => NACK
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 5 ) ;    // clear STA

          return I2C_STATUS_FAILURE_NACK_ADDR;
      }
      case 0x50 : { // Section 15.11.3, receive  : data         =>  ACK
        if( --n <= 1 ) {
          *x++        = I2C->DAT;       // get   data         
          I2C->CONCLR = ( 1 << 2 ) |    // clear AA
                        ( 1 << 3 ) |    // clear SI 
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA

          break;
        }
        else {
          *x++        = I2C->DAT;       // get   data         
          I2C->CONSET = ( 1 << 2 ) ;    // set   AA 
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI 
                        ( 1 << 4 ) |    // clear STO
                        ( 1 << 5 ) ;    // clear STA          

          break;
        }
      }
      case 0x58 : { // Section 15.11.3, receive  : data         => NACK
        if( n != 0 ) {
          *x++        = I2C->DAT;       // get   data 
        }
          I2C->CONSET = ( 1 << 2 ) |    // set   AA 
                        ( 1 << 4 ) ;    // set   STO
          I2C->CONCLR = ( 1 << 3 ) |    // clear SI
                        ( 1 << 5 ) ;    // clear STA        

          return I2C_STATUS_SUCCESS;
      }
    }
  }

  return I2C_STATUS_SUCCESS;
}

i2c_status_t target_i2c_rd( i2c_addr_t a, uint8_t* x, size_t n ) {
  return target_i2c_fsm( a, I2C_MODE_RD, x, n );
}

i2c_status_t target_i2c_wr( i2c_addr_t a, uint8_t* x, size_t n ) {
  return target_i2c_fsm( a, I2C_MODE_WR, x, n );
}
