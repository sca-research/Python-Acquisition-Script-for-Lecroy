/* Copyright (C) 2017 Daniel Page <dan@phoo.org>
 *
 * Use of this source code is restricted per the CC BY-SA license, a copy of
 * which can be found via http://creativecommons.org (and should be included 
 * as LICENSE.txt within the associated archive or repository).
 */

#ifndef __BSP_H
#define __BSP_H

#include <stdbool.h>
#include  <stdint.h>
#include  <string.h>

#define RSVD(x,y,z) uint8_t reserved_##x[ z - y + 1 ]

#define RO volatile const /* read  only */
#define WO volatile       /* write only */
#define RW volatile       /* read/write */
#define WR volatile       /* write/read */

typedef enum {
  GPIO_PIN_TRG,
  GPIO_PIN_GPO,
  GPIO_PIN_GPI
} gpio_pin_t;

typedef uint8_t i2c_addr_t;

typedef enum {
  I2C_MODE_WR = 0x00,
  I2C_MODE_RD = 0x01
} i2c_mode_t;

typedef enum { 
  I2C_STATUS_SUCCESS           = 0x00,
  I2C_STATUS_FAILURE           = 0x01,
  I2C_STATUS_FAILURE_NACK_ADDR = 0x02,
  I2C_STATUS_FAILURE_NACK_DATA = 0x03
} i2c_status_t;

#endif
